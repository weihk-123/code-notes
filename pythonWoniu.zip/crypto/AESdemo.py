#对明文进行AES的加解密

from Crypto.Cipher import AES
from binascii import b2a_hex,a2b_hex
#明文
source = 'hello-你好'

#加密
#对aes的明文进行分组，补位
if len(source.encode('utf-8')) % 16:
    #如果不够算出差多少个字节
    add = 16 - (len(source.encode('utf-8')) % 16)
else:
    add = 0
source = source + ('\0' * add)
# print(source)

#定义密钥和偏移量(字节类型)
#密钥的要求：长度必须为128，192，256中的一种
# 也就是16，24，32个字节
key = 'todayiswonderful'.encode()
mode = AES.MODE_CBC
iv = b'todayiswonderful'
cryptos = AES.new(key,mode,iv)   #实例化出一个AES的加密对象
cipher = cryptos.encrypt(source.encode())
print(cipher)
print(b2a_hex(cipher).decode()) #转换成十六进制便于观看和传输


#解密
source = '18bb7e0a01ef98378b7802f090e03853'    #密文
key = 'todayiswonderful'.encode()
mode = AES.MODE_CBC
iv = b'todayiswonderful'
cryptos = AES.new(key,mode,iv)
password = cryptos.decrypt(a2b_hex(source))
print(password.decode().rstrip('\0'))  #rstrip过滤掉补足的空字符
