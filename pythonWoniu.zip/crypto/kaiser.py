'''
凯撒密码的中文版,按照中文的Ascll码进行移位
'''
source = '蜗牛学院'
for c in source:
    ascii = ord(c)
    ascii += 1
    print(chr(ascii),end='')
print('')
source = '蜘牜孧陣'
for c in source:
    ascii = ord(c)
    ascii -= 1
    print(chr(ascii),end='')