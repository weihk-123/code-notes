import hashlib

#md5
source = 'hentai'
print(hashlib.md5(source.encode()).hexdigest())

with open('./2.jpg',mode='rb') as f:
    data = f.read()
print(hashlib.md5(data).hexdigest())

#sha
print(hashlib.sha256(source.encode()).hexdigest())