import base64
import os

# 对某个文件进行base64转码并加密保存
def encrypt(filepath):
    with open(filepath,mode='rb') as f:
        data = f.read()
    source = base64.b64encode(data).decode()
    # 加密用凯撒右移五位
    dest = ''
    for c in source:
        dest += chr(ord(c)+5)
    #将加密字符串保存到文件中
    with open(filepath + '.enc',mode='w') as f:
        f.write(dest)
    #删除源文件
    os.remove(filepath)

#解密
def decrypt(filepath):
    with open(filepath,mode='r',) as f:
        content = f.read()
    dest = ''
    for c in content:
        dest += chr(ord(c) - 5)

    newfile = filepath.replace('.enc','')
    with open(newfile,mode='wb',) as f:
        f.write(base64.b64decode(dest))
    os.remove(filepath)

#遍历目录输出目录中的所有文件名
def get_file(directory_path):
    files = [f for f in os.listdir(directory_path) if os.path.isfile(os.path.join(directory_path, f))]
    file_list=[]
    for file in files:
        file_list.append(file)
    return file_list

 # 遍历目录，对关键文件加密
def dircencrypt(directory_path,suffix):
    # directory = 'C://Users/dalhvkda/Desktop/图片'
    for file in get_file(directory_path):
        if file.endswith(suffix):
            encrypt(directory_path + '/' + file)

 # 遍历目录，对关键文件解密
def dircdecrypt(directory_path,suffix):
    for file in get_file(directory_path):
        if file.endswith(suffix+'.enc'):
            decrypt(directory_path + '/' + file)

if __name__ == '__main__':
    # encrypt('./2.jpg')
    # decrypt('./kaiser.py')
    #输入要加密的目录的名字
    directory_path = 'C://Users/dalhvkda/Desktop/password_ky5ba'
    #输入要加密的文件的后缀名
    suffix = '.jpg'
    dircencrypt(directory_path,suffix)
    # dircdecrypt(directory_path,suffix)