#RSA的加解密过程
import rsa
from binascii import b2a_hex,a2b_hex
#第一个是b2a_hex二进制转换为十六进制的函数，第二个a2b_hex是十六进制转换为二进制的函数

#rsa加密
#生成RSA公钥和私钥
#参数为密钥长度
pub, priv = rsa.newkeys(256)
print(pub)
print(priv)

#公钥加密
#参数为要加密的明文和公钥
encrypt = rsa.encrypt('hello'.encode(),pub)
print(encrypt)      #库rsa处理加密过后就变成了二进制的字节类型
print(b2a_hex(encrypt).decode())      #将字节转换为16进制,为了方便传输

#私钥解密
#解密也是对二进制的字节类型进行处理，如果不是需要进行转换
decrypt = rsa.decrypt(encrypt,priv)
print(decrypt.decode())
