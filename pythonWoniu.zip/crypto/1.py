import base64


def base64_decode(ciphertext):
    try:
        decoded_bytes = base64.b64decode(ciphertext)
        return decoded_bytes.decode('utf-8')
    except Exception as e:
        print(f"解密出错: {e}")
        return None


ciphertext = "YWRtaW4="
plaintext = base64_decode(ciphertext)
if plaintext:
    print("解密后的明文是:", plaintext)
