import time,math
#质数因子求解
#已知n求pq

#判断是否为质数
def is_prime(n):
    #任何数其因子只需要找小于其开根号的整数即可
    for i in range(2,int(math.sqrt(n))+1):
        if n % i == 0:
            return False
    return True
#求n的因数
def prime_pq(n):
    start = time.time()
    for p in range(1,n//2+1):
        for q in range(1,n//2+1):
            if p * q == n and is_prime(p) and is_prime(q):
                print(p,q)
                end = time.time()
                print(end -start )
                exit(0)
            # else:
                # print(p,q)


if __name__ == '__main__':
    # prime_pq(99400891)
    prime_pq(967381)