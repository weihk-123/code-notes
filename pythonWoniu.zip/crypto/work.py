#场景：张三用凯撒右移加密字符串，李四对一次加密后的进行大小写转换
# 张三对二次加密的进行一次凯撒解密
# 李四得到后用李四的大小写互换得到最初的密文
#由此实现了传输过程都是密文，双方不交换密钥
import string
#取得所有的大写字母
upper = string.ascii_uppercase
#取得所有的小写字母
lower = string.ascii_lowercase

#凯撒加密字母右移五位
def encrypt_kaiser(source):
    dest = ''
    for c in source:
        if c in upper:
            index = (upper.index(c) + 5) % 26
            dest += upper[index]
        elif c in lower:
            index = (lower.index(c) + 5) % 26
            dest += lower[index]
    return dest

#凯撒密码解密，对字母进行左移五位
def decrypt_kaiser(source):
    dest = ''
    for c in source:
        if c in upper:
            index = (upper.index(c) - 5) % 26
            dest += upper[index]
        elif c in lower:
            index = (lower.index(c) - 5) % 26
            dest += lower[index]
    return dest

#大小写转换
def convert(source):
    dest = ''
    for c in source:
        if ord(c) >=65 and ord(c) <=90:
            dest += chr(ord(c) + 32)
        elif ord(c) >= 97 and ord(c) <= 122:
            dest += chr(ord(c) - 32)
    return dest

if __name__ == '__main__':
    re1 = encrypt_kaiser('niHAO')
    print(re1)
    re2 = convert(re1)
    print(re2)
    re3 = decrypt_kaiser(re2)
    print(re3)
    re4= convert(re3)
    print(re4)