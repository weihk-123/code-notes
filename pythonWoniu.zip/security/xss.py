import requests
#用于检测响应是否有效
def check_resp(response,payload,type):
    index = response.find(payload)
    prefix = response[index-2:index-1]
    if type == "Normal" and prefix != '=' and index >=0:
        return True
    elif type == 'Prop' and prefix == '=' and index >=0:
        return True
    elif index >= 0:
        return True
    return False
#html实体字符转换
def string_html(text):
    return ''.join(f"&#x{ord(char):X};" for char in text)
#实现xss扫描的主功能
def xss_scan(location):
    url = location.split('?')[0]
    param = location.split('?')[1].split('=')[0]
    with open('../dict/xss-payload.txt') as file:
        payload_list=file.readlines()
    for payload in payload_list:
        type = payload.strip().split(':', 1)[0]
        payload = payload.strip().split(':', 1)[1]
        if type == 'Escape':
            payload = string_html(payload)
        if type == 'Referer' or type == 'User-Agent' or type == 'Cookie':
            header = {type:payload}
            resp = requests.get(url=url, headers=header)
        else:
            resp = requests.get(url=url, params={param: payload})
            # print(payload,resp.text)
        if type == 'Cookie':
            payload=payload.split('=',1)[1]
        if check_resp(resp.text,payload,type):
            print(f"此处存在xss漏洞：{payload}")


if __name__ == '__main__':
    # xss_scan('http://localhost/xss/level2.php?keyword=test')
    # xss_scan('http://localhost/xss/level1.php?name=test')
    # xss_scan('http://localhost/xss/level8.php?keyword=test')
    xss_scan('http://localhost/xss/level17.php?arg01=a&arg02=b')