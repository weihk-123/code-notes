#需要先开启socket服务器，与服务器连接后这个py页面就变成了客户端
import socket

#定义一个客户端连接
def test_client():
    #建立与服务器的连接
    s=socket.socket()       #默认使用tcp协议
    s.connect(('localhost',554))
    #发送数据包
    content="Welcome to woniu College"
    s.send(content.encode())

    #关闭连接
    s.close()

#定义一个服务器端
def test_server():
    s=socket.socket()
    s.bind(('127.0.0.1',555))  #绑定服务器端ip和端口号
    s.listen()      #保持对555端口的监听
    while True:
        chanel,client=s.accept()    #接受来自客户端的数据,client包含客户端的ip地址,端口号,chanel指连接通道
        message=chanel.recv(1024)
        print(message.decode())

test_server()
