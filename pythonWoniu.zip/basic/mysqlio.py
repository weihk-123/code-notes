import pymysql
from pymysql.cursors import DictCursor

#查询操作
#创建连接，连接phpstudy的mysql
# conn=pymysql.connect(host='localhost',user='root',password='root',database='learn',charset='utf8')
# sql="select username,password,role from user where userid<6"
# #定义游标对象,用于取得返回值
# # cursor=conn.cursor()
# cursor=conn.cursor(DictCursor) #将返回值设置为列表加字典的格式
# cursor.execute(sql)
# #获取结果集,默认情况下返回的是一个二维元组
# result=cursor.fetchall()
# # print(result)
# for i in result:
#     print(i['username'])


#更新操作
#必须确认提交，不然操作无效
#创建连接对象时加上参数设置autocommit=True，或者在代码中显式提交(连接对象.commit())
conn=pymysql.connect(host='localhost',user='root',password='root',database='learn',charset='utf8')
cursor=conn.cursor()
sql="update user set password='admin123' where userid=13"
cursor.execute(sql)
conn.commit() #显式提交
#关闭连接
conn.close()