import random
def guess_numbers (x,y):
    number=random.randint(x,y)
    while True:
        z = int(input('请输入一个整数:'))
        if number == z:
            print('恭喜你猜对了')
            break
        elif number > z:
            print('猜小了')
        else:
            print('猜大了')
guess_numbers(1,1000)
