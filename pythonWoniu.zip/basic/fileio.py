# f = open('text.txt', encoding='utf-8')
# content=f.read()
# print(content)
# f.close()

# f = open('text.txt',mode="a",encoding='utf-8')
# f.write('\nhello world')
# f.close()
#
# f = open('text_01.txt',mode="w",encoding='utf-8')
# f.write('\nhello world this is text_01.txt')
# f.close()

# f = open('text_01.txt')
#注意写入文件的编码格式要和打开文件的编码格式一致
# content = f.read(10)
# # read()不带参数读所有，带了参数表示指定读取文件的长度
# #readline() 读取一行的参数
# #readlines() 按行全部读取并且按行分割，保存到列表中
# print(content)
# f.close()


#CSV文件的读写
#将csv文件中的数据变成python的列表包含字典的格式
f=open('userpass.csv')
line_list=f.readlines()
#取得列名,也就是字典的key
key=line_list[0]
user_list=[]
key=key.strip()
key=key.split(',')


for i in range(1,len(line_list)):
    line=line_list[i].strip()
    #取得字典的值，也就是每一行的值
    username=line.split(',')[0]
    password=line.split(',')[1]
    expect=line.split(',')[2]
    user_dict={}
    user_dict[key[0]]=username
    user_dict[key[1]]=password
    user_dict[key[2]]=expect
    user_list.append(user_dict)
print(user_list)
# for i in user_list:
#     print(i['username'])
f.close()
