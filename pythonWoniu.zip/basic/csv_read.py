'''
读出csv文件的内容并转换成python的列表包含字典[{},{},{},{}]的格式
第一个参数传入文件名，第二个参数用于声明是否有字典的key
以＃号开头的一行不进行处理
'''
def csv_read(filename,has_column=True):
    #has_column用于判断第一行是否是字典的键
    #如果第一行不是键也就是不包含字典的 键就不支持转化为该格式
    f=open(filename)
    line_list=f.readlines()

    if not has_column:
        try:
            raise Exception
        except Exception as e:
            print('CSV文件必须要使用第一行作为列明')
    else:
        # 取得列名,也就是字典的key
        key=line_list[0]
        #对key进行处理,去掉多于的\n和,
        key=key.strip().split(',')
        user_list=[]
        for i in range(1,len(line_list)):
            #如果以#开头表示该用户被禁用跳过这次循环
            if line_list[i].startswith('#'):
                continue
            temp_list=line_list[i].strip().split(',')
            user_dict={}
            for j in range(len(temp_list)):
                user_dict[key[j]] = temp_list[j]
            user_list.append(user_dict)
        f.close()
        return user_list

# if __name__ == '__main__':
#     result=csv_read('userpass.csv')
#     print(result)


#python自带得用于读写csv文件的库
if __name__ == '__main__':
    import csv
    with open('userpass.csv') as f:
        # result_list= csv.reader(f)
        # for item in result_list:
        #     print(item)
        #结果：['username', 'password', 'phone']

        # csv_list=csv.reader(f)
        # print(list(csv_list))
        #结果为所有行放在一个二维列表

        csv_result=csv.DictReader(f)
        for user in csv_result:
            print(dict(user))
