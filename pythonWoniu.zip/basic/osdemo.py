import os
# os.system("ipconfig")      #执行系统命令并输出结果
# eval("print('hello')")      #将字符串当作代码执行
result=os.popen("ipconfig").read()     #执行系统命令，将结果赋值给一个变量
print(result)