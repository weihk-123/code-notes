#使用正则表达式的第三方库
import re
from basic.csv_read import csv_read
import pymysql
from pymysql.cursors import DictCursor
'''
判断用户名是否有效
长度的判断5-12位
不能以数字开头
只能是大小写或数字
'''
def check_username(username):
    if len(username)<5 or len(username)>12:
        return False
    if username[0] >= '0' and username[0] <= '9':
        return False
    for char in username:
        if not (ord(char) in range(65,91) or ord(char) in range(97,123) or ord(char) in range(48,58)):
            return False
    return True

'''
检查密码:由大写，小写和数字构成
也就是至少一位是大写，至少1位是小写，至少1位是数字
6~15位
'''
def check_password(password):
    if len(password)<6 or len(password)>15:
        return False

    lower = 0
    upper = 0
    digit = 0
    other = 0
    for chr in password:
        if chr >='A' and chr <='Z':
            upper +=1
        elif chr >='0' and chr <='9':
            digit +=1
        elif chr >='a' and chr <='z':
            lower +=1
        else:
            other+=1
    if lower==0 or upper==0 or digit==0 or other>0 :
        return False
    return True

def check_phone(phone):
    pattern="^1[3-9]\d{9}$"
    #re.match 第一个参数正则表达式的匹配模式，第二个参数要匹配的字符串
    if re.match(pattern,phone):
        return True
    else:
        return False

#测试函数，当函数执行结果与期望值一样时返回测试成功
#TDD:Test_Driven Development
def text_driver(func,expect,*args):
    actual = func(*args)
    if actual == expect:
        print('测试%s:成功'% func.__name__)
    else:
        print('测试%s:失败'% func.__name__)

'''
读出csv文件的内容并转换成python的列表包含字典[{},{},{},{}]的格式
第一个参数传入文件名，第二个参数用于声明是否有字典的key
'''
def csv_read(filename,has_column=True):
    #has_column用于判断第一行是否是字典的键
    #如果第一行不是键也就是不包含字典的 键就不支持转化为该格式
    f=open(filename)
    line_list=f.readlines()

    if not has_column:
        try:
            raise Exception
        except Exception as e:
            print('CSV文件必须要使用第一行作为列明')
    else:
        # 取得列名,也就是字典的key
        key=line_list[0]
        #对key进行处理,去掉多于的\n和,
        key=key.strip().split(',')
        user_list=[]
        for i in range(1,len(line_list)):
            temp_list=line_list[i].strip().split(',')
            user_dict={}
            for j in range(len(temp_list)):
                user_dict[key[j]] = temp_list[j]
            user_list.append(user_dict)
        f.close()
        return user_list
#读取csv文件，并检查用户名是否存在
#存在返回True，不存在返回False
def check_user_exists(username):
    user_list = csv_read('userpass.csv')
    for user in user_list:
        if user['username'] == username:
            return True
    return False

def check_get_user(username):
    user_list = csv_read('userpass.csv')
    for user in user_list:
        if user['username'] == username:
            return user
    return None

#修改用户的密码
#将csv整体读入到内存中，形成列表+字典，然后修改字典的某一项，再整体写入到csv（覆盖写入）
def change_password(username,newpass):
    csv_list=csv_read('userpass.csv')
    for user in csv_list:
        if user['username'] == username:
            index=csv_list.index(user)
            break
    csv_list[index]['password']=newpass
    with open('userpass.csv',mode='w') as f:
        f.write('username,password,phone\n')
        for user in csv_list:
            line= f'{user["username"]},{user["password"]},{user["phone"]}\n'
            f.write(line)

            # for v in user.values():
#针对数据库连接进行封装操作
def query_mysql(sql):
    conn = pymysql.connect(host='localhost', user='root', password='root', database='learn', charset='utf8')
    cursor = conn.cursor(DictCursor)
    cursor.execute(sql)
    result = cursor.fetchall()
    conn.close()
    return result

def query_mysql_2(sql):
    try:
        conn = pymysql.connect(host='localhost', user='root', password='root', database='learn', charset='utf8')
        cursor = conn.cursor(DictCursor)
        cursor.execute(sql)
        result = cursor.fetchall()
        return result
    except:
        raise Exception("数据库处理出错")
    finally:
        conn.close()
def update_mysql(sql):
    conn = pymysql.connect(host='localhost', user='root', password='root', database='learn', charset='utf8')
    cursor = conn.cursor(DictCursor)
    cursor.execute(sql)
    conn.commit()  # 显式提交
    # 关闭连接
    conn.close()

if __name__ == '__main__':
    pass
    # change_password()
    # try:
    #     result=query_mysql_2("select * from user")
    #     print(result)
    # except:
    #     pass
    #测试用户名
    # text_driver(check_username,True,'wwwwwww')
    # text_driver(check_username,False,'1222222')
    # text_driver(check_username,False,'adsadaswdasda')
    # text_driver(check_username,False,'ad%swda==')
    # text_driver(check_username,False,'ad')

    #测试密码
    # text_driver(check_password,False,'wD1')
    # text_driver(check_password,False,'DWWDdwljlj123afjsiafasfsa')
    # text_driver(check_password,False,'wdwdwdwd12')
    # text_driver(check_password,False,'DSADSD123')
    # text_driver(check_password,True,'DSdasADD123')
    # text_driver(check_password,False,'DdsAD#$123')

    #测试电话号码
    # text_driver(check_phone,True,'13812345678')
    # text_driver(check_phone,False,'138123456781')
    # text_driver(check_phone,False,'23812345678')
    # text_driver(check_phone,False,'11812345678')
    # text_driver(check_phone,False,'11812345a78')