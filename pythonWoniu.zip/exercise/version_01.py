'''
版本一：注册功能，对用户的输入进行验证
规则：用户名只能是大小写或数字，但不能以数字开头，5~12位
密码只能由大小写和数字组成，长度位6~15位
手机号1开头第二位为3-9，11位，都是数字
验证成功将用户信息保存到列表或字典中
'''
from exercise.common import check_password,check_phone,check_username
def input_username():
    username = input('请输入用户名：')
    if check_username(username):
        print('用户名正确')
        return username
    else:
        print('用户名错误')
        input_username()
def input_password():
    password = input('请输入密码：')
    if check_password(password):
        print('密码正确')
        return password
    else:
        print('密码错误')
        input_password()
def input_phone():
    phone = input('请输入电话号码：')
    if check_phone(phone):
        print('电话号码正确')
        return phone
    else:
        print('电话号码错误')
        input_phone()
def do_reg():
    username=input_username()
    password=input_password()
    phone=input_phone()
    user_list=[]
    user={'username':username,'password':password,'phone':phone}
    user_list.append(user)
if __name__ == '__main__':
    do_reg()