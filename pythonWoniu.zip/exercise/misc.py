import json
from exercise.common import *

row_list = query_mysql("select username,password from user where userid <4")
print(row_list)
print(type(row_list))

jsonstr=json.dumps(row_list)  #将python的储存格式序列化为json字符串
print(jsonstr)
print(type(jsonstr))

#将json字符串反序列化为python对象
js='[{"username": "woniu", "password": "123456"}, {"username": "qiang", "password": "654321"}]'
jsonobj=json.loads(js)
print(jsonobj[0]['username'])
print(type(jsonobj))

#json.load和json.dump用于操作文件