'''
版本二
给用户设定菜单，让用户可以决定下一步干什么
支持多用户注册，注册时如果已经存在的用户名不能注册
将注册的用户名密码电话等信息，保存在文本文件中（csv文件）.
'''
from exercise.common import *
def input_username():
    username = input('请输入用户名：')
    if check_username(username):
        if check_user_exists(username):
            print('用户名已存在')
            return input_username()
        else:
            print('用户名正确')
            return username
    else:
        print('用户名错误')
        return input_username()
def input_password():
    password = input('请输入密码：')
    if check_password(password):
        print('密码正确')
        return password
    else:
        print('密码错误')
        return input_password()
def input_phone():
    phone = input('请输入电话号码：')
    if check_phone(phone):
        print('电话号码正确')
        return phone
    else:
        print('电话号码错误')
        return input_phone()
def do_reg():
    username=input_username()
    password=input_password()
    phone=input_phone()

    with open('userpass.csv',mode='a') as f:
        f.write(f'\n{username},{password},{phone}')
        print('注册成功！')
    draw_menu()
def do_login():
    username = input('请输入用户名:')
    password = input('请输入密码:')
    user = check_get_user(username)
    if user is None:
        print('用户名不存在')
        exit(0)    #强制结束代码
    elif user['password']==password:
        print('用户名密码正确，登录成功')
    else:
        print('登录失败')
    draw_menu()

def do_change():
    username = input('请输入用户名:')
    password = input('请输入旧密码:')
    user = check_get_user(username)
    if user is None:
        print('用户名不存在')
        draw_menu()
    elif user['password'] == password:
        newpass=input('请输入新密码')
        if check_password(newpass):
            change_password(username,newpass)
            print('密码修改成功')
            draw_menu()
        else:
            print('新密码格式不正确')
            draw_menu()
    else:
        print('旧密码验证失败')
        draw_menu()
def draw_menu():
    print('===============请选择要进行的操作=================')
    print("1.注册  2.登录  3.修改密码  4.退出")
    option = input('请选择菜单项 ：[1,2,3]:')
    if option == '1':
        do_reg()
    elif option== '2':
        do_login()
    elif option == '3':
        do_change()
    elif option=='4':
        exit(0)
    else:
        print('请输入正确的菜单编号.')
        return draw_menu()
if __name__ == '__main__':
    # do_reg()
    # do_login()
    draw_menu()
    # do_change()