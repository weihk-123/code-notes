netstat = '''tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN     
tcp        0      0 127.0.0.1:25            0.0.0.0:*               LISTEN     
tcp        0     64 192.168.222.140:22      192.168.222.1:61851     ESTABLISHED
tcp        0      1 192.168.222.140:53484   192.168.187.87:3306     SYN_SENT   
tcp        0      0 192.168.222.140:22      192.168.222.1:61850     ESTABLISHED'''
line_list = netstat.split('\n')
ip_list = []
for line in line_list:
    temp_list = line.split()
    ip = temp_list[4].split(':')[0]
    # print(ip)
    ip_list.append(ip)
    print(temp_list)