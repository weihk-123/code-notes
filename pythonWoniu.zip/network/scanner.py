#各类扫描

import socket,threading,os
from scapy.layers.inet import IP, TCP
from scapy.layers.l2 import ARP
from scapy.sendrecv import sr1
#对目标ip进行端口扫描
def socket_port(ip):
    for port in range(1,65536):
        try:
            s = socket.socket()
            #优化：因为tcp连接失败会重新进行请求，会消耗大量时间，这里让其0.5秒没有回应就放弃开始连接下一个端口
            #根据实际情况，网速进行更改
            s.settimeout(0.0001)
            s.connect((ip,port))
            print(f'端口:{port}可用')
            s.close()
        except ConnectionRefusedError:
            pass
            # print(f'端口:{port}不可用')
        except socket.timeout:
            pass
            # print(f'端口:{port}不可用')
            # pass
#基于多线程进行端口扫描
def socket_port_thread(ip,start):
    for port in range(start,start+50):
        try:
            s = socket.socket()
            s.settimeout(0.5)
            s.connect((ip,port))
            print(f'端口:{port}可用')
            s.close()
        except:
            pass

#优化，优先扫描常用端口

#ip扫描
#要进行内网渗透，就需要扫描ip
#使用ping进行扫描,但是icmp默认是会被防火墙阻挡
def ping_ip():
    for i in range(1,255):
        ip = f'192.168.61.{i}'
        output = os.popen(f'ping -n 1 -w 10 {ip}').read()
        if 'TTL=' in output:
            print(f'{ip} online')

#使用scapy发送arp请求实现ip扫描
def scapy_ip(start):
    for i in range(start,start+5):
        ip = f'192.168.222.{i}'
        try:
            pkg = ARP(psrc="192.168.222.1", pdst=ip)
            reply = sr1(pkg, timeout=1, verbose=False)  # verbose=False不显示具体回显信息
            print(reply[ARP].hwsrc)
            print(f' {ip}在线')
        except:
            pass
#基于tcp半连接的标志位,实现端口扫描
def scapy_port(ip):
    #源ip如果是本机可以不写
    for port in range(79, 3306):
        try:
            pkg = IP(dst=ip)/TCP(dport=port,flags='S')
            reply=sr1(pkg,timeout=1,verbose=False)
            if reply[TCP].flags == "SA":
                print(f'端口:{port}开放')
        except:
            pass

#基于ping命令的子域名扫描
def ping_domain():
    with open('../dict/subdomain-top160k.txt') as f:
        domain_list= f.readlines()

    for domain in domain_list:
        result = os.popen(f"ping -n 1 -w 1000 {domain.strip()}.woniuxy.com").read()
        if '找不到主机' not in result:
            print(f'{domain.strip()}.woniuxy.com')

#基于socket库的DNS解析功能实现扫描
def socket_domain():
    with open('../dict/subdomain-top160k.txt') as f:
        domain_list= f.readlines()

    for domain in domain_list:
        try:
            ip = socket.gethostbyname(f'{domain.strip()}.woniuxy.com')
            print(f'{domain.strip()}.woniuxy.com,ip:{ip}')
        except socket.gaierror:
            pass

#查询域名的whois信息
def whois_info():
    from whois import whois
    result = whois('woniuxy.com')
    import  json
    #转换为json
    dict = json.loads(str(result))
    print(dict)
if __name__ == '__main__':
    # socket_port('192.168.222.140')

    #基于多线程的端口扫描
    # for i in range(1,3500,50):
    #     threading.Thread(target=socket_port_thread,args=('192.168.222.140',i)).start()

    # ping_ip()

    # scapy_ip()
    #多线程扫描ip
    # for i in range(1, 255, 5):
    #     threading.Thread(target=scapy_ip,args=(i,)).start()

    scapy_port('192.168.222.142')
    # ping_domain()
    # socket_domain()
    # whois_info()