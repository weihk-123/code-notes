import socket
s = socket.socket()
s.connect(('192.168.222.131',6379))
#登录
#auth 123456
s.send("*2\r\n$4\r\nAUTH\r\n$6\r\n123456\r\n".encode())
#set name woniuxy
s.send('*3\r\n$3\r\nset\r\n$4\r\nname\r\n$7\r\nwoniuxy\r\n'.encode())
s.send("*2\r\n$3\r\nget\r\n$4\r\nname\r\n".encode())
response = s.recv(1024)
print(response.decode('utf-8'))
s.close()