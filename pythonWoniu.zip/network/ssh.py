import  paramiko

#建立与ssh服务器的连接
#指定IP地址，端口号，账号和密码
transport = paramiko.Transport(('192.168.222.131',22))
transport.connect(username='root',password='p-0p-0p-0')

#实例化ssh客户端，用于执行命令
ssh = paramiko.SSHClient()
ssh._transport = transport

#实例化sftp用于传输文件
sftp = paramiko.SFTPClient.from_transport(transport)

#执行命令,并获取结果
#该函数有三个返回值，标准输入，输出，错误，用三个变量来接收
# stdin,stdout,stderr = ssh.exec_command('free')
# print(stdout.read().decode())

#传输文件
# sftp.put('./2.jpg','/opt/2.jpg')   #要传输的本地文件德路径，要在目标主机存放的路径
sftp.get('/opt/redis-6.2.5.tar.gz','./redis.tar.gz')  #要下载的文件的绝对路径，要存放在本地的路径