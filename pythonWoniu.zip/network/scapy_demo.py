#使用scapy发送arp请求实现ip扫描
import random
import time

import scapy
from scapy.layers.inet import IP, TCP
from scapy.layers.l2 import ARP
from scapy.packet import Raw
from scapy.sendrecv import sr1
# try:
#     pkg=ARP(psrc="192.168.222.1",pdst='192.168.222.140')
#     reply = sr1(pkg,timeout=1,verbose=False)     #verbose=False不显示具体回显信息
#     print(reply[ARP].hwsrc)
#     print(f'IP在线')
# except:
#     pass


#使用scapy完成三次握手
seq = random.randint(10000,20000)
sport = random.randint(12000,30000)
pkg_1 = IP(dst='169.254.138.144')/TCP(sport=sport,dport=6666,flags='S',seq=seq)
reply = sr1(pkg_1)
seq = reply[TCP].ack
ack = reply[TCP].seq + 1
pkg_2 = IP(dst='169.254.138.144')/TCP(sport=sport,dport=6666,flags='A',seq=seq,ack=ack)
sr1(pkg_2,timeout=3,verbose=False)

#三次握手后，发送消息
pkg_3 = IP(dst='169.254.138.144')/TCP(sport=sport,dport=6666,flags='PA',seq=seq,ack=ack)/"nihaohhhhhhhhhh"
reply = sr1(pkg_3)
time.sleep(1)
print(f'服务器回复:{reply[Raw].load}')