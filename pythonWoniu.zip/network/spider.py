import re,requests,random
import time

def download_page():
    resp = requests.get('http://www.zenghuinote.asia/')
    #解析网页所有超链接
    #第一个参数为查找规则，第二个为要查找的字符串
    links=re.findall('<a href="(.+?)"',resp.text)
    for link in links:
        #对无用的超链接进行排除
        if link.startswith('#'):
            continue
        #将相对地址拼接为绝对地址
        if link.startswith('/'):
            link="http://www.zenghuinote.asia/"+link

        resp = requests.get(link)
        resp.encoding='utf-8'
        filename=link.split('/')[-1]+time.strftime("_%Y%m%d_%H%M%S")+'.html'
        with open(f'./woniunote/page/{filename}',mode='w',encoding='utf-8') as f :
            f.write(resp.text)

#爬取图片
def downnload_image():
    resp = requests.get('http://www.zenghuinote.asia/')
    images=re.findall('<img src="(.+?)"',resp.text)
    for image in images:
        if image.startswith("/"):
            image='http://www.zenghuinote.asia/'+image
        resp=requests.get(image)
        filename = time.strftime("_%Y%m%d_%H%M%S")+image.split('/')[-1]
        with open('./woniunote/images/'+filename,mode='wb') as f :
            f.write(resp.content)
if __name__ == '__main__':
    downnload_image()
