import threading,time,requests
def test_01():
    for i in range(5):
        print(threading.current_thread().getName())    #输出当前线程的名字
        #没有手动启动会默认启动一个主线程
        print(time.strftime('%Y-%m-%d %H:%M:%S'))
        time.sleep(5)

def test_02():
    print(threading.current_thread().getName())
    print(time.strftime('%Y-%m-%d %H:%M:%S'))
    time.sleep(5)
session=requests.session()

#访问首页
def home():
    resp=session.get('http://192.168.131.207:8080/woniusales/')
    # if '成都蜗牛创想科技有限公司' in resp.text:
    #     print('首页访问成功')
    # else:
    #     print('首页访问失败')

def login():
    data = {'username': 'admin', 'password': 'admin','verifycode':'0000'}
    resp= session.post(url='http://10.0.142.185:8080/woniusales/user/login',data=data)
    # if resp.text == 'login-pass':
    #     print('登录成功')
    # else:
    #     print('登录失败')
    print(resp.text)
#使用多线程实现流量泛洪
def woniusales_flood():
    for i in range(1000):
        try:
            home()
            # login()
        except:
            pass
if __name__ == '__main__':
    # test_01()
    # for i in range(1000):
    #     #创建线程,传入参数target指定的是多线程要调用的函数，如果该函数需要传参用arges传入
    #     t=threading.Thread(target=woniusales_flood)
    #     t.start()
    login()