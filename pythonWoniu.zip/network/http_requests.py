import requests

#发送GET请求
# resp = requests.get('http://localhost/learn/farmingGame/login-1.php')
# resp.encoding='utf-8'    #设置返回值的编码
# print(resp.text)   #输出返回值

#发送POST请求
# data={'username':'jim','password':'123456'}
# resp= requests.post(url='http://localhost/learn/farmingGame/login-1.php',data=data)
# # print(resp.text)
# #登陆成功后获取响应的cookie
# cookie=resp.cookies

#resp.text是文本型的响应内容，resp.content是二进制的响应内容
#下载图片
# resp= requests.get('http://woniunode.cn/static/img/banner-1.jpg')
# with open('./banner.jpg',mode="wb") as f:
#     f.write(resp.content)

#文件上传
# file={'batchfile':open('要上传的文件地址','rb')}
# data={'batchname':'GB20110232'}
# resp=requests.post(url='',data=data,files=file,cookies=cookie)



#除了获取cookie然后在发送请求时带上cookie来维持登陆状态，还有一种方法
#这种方法是requests库中的模块session自动帮我们检查cookie并自动发送
session=requests.session()
data = {'username':'jim','password':'123456'}
resp = session.post(url='http://localhost/learn/farmingGame/login-1.php',data=data)
file={'batchfile':open('要上传的文件地址','rb')}
data={'batchname':'GB20110232'}
resp = session.post(url='',data=data,files=file)
print(resp.text)

#利用python直接处理json
import json
list=json.loads(resp.text)    #将json字符串反序列化为python可以操作的列表,json.dumps()为序列化


#处理https请求
resp=requests.get('',verify=False)   #忽略证书
print(resp.text)