#使用python给qq邮箱发送邮件
#需要先在qq打开服务并获取是授权码
import smtplib
from email.mime.image import MIMEImage
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.header import Header
import os
import threading
# 发件人邮箱
sender = '971209914@qq.com'
# 发件人邮箱的授权码（需在QQ邮箱设置中获取)
password = 'pqeserhoxmurbegj'
# 收件人邮箱，可以是多个收件人，用逗号隔开
recipient = '3198242592@qq.com'

# 邮件主题
subject = '测试邮件'
# 邮件正文内容
body = '''<a href='http://www.baidu.com'>这是一封使用Python发送的测试邮件</a>'''
# 创建一个MIMEText对象，设置内容、格式（这里是纯文本格式 'plain'，也可以是 'html' 用于发送HTML格式邮件）以及编码
message = MIMEText(body, 'html', 'utf-8')
# 设置邮件头部的主题信息，注意编码
message['Subject'] = Header(subject, 'utf-8')
# 设置发件人信息
message['From'] = sender
# 设置收件人信息
message['To'] = recipient
def send_qqmail(message):
    try:
        # 创建SMTP对象，连接到QQ邮箱的SMTP服务器，QQ邮箱的SMTP服务器地址是'smtp.qq.com'，端口号是587（也可以尝试使用465端口）
        server = smtplib.SMTP('smtp.qq.com', 587)
        # 启动TLS加密（增强安全性）
        server.starttls()
        # 登录发件人邮箱，使用授权码登录
        server.login(sender, password)
        # 发送邮件，传入发件人、收件人（可以是列表形式的多个收件人）、邮件内容（字符串形式）
        server.sendmail(sender, recipient, message.as_string())
        print("邮件发送成功")
        server.quit()
    except smtplib.SMTPException as e:
        print("邮件发送失败:", e)
# for i in range(10):
#     t=threading.Thread(target=send_qqmail)
#     t.start()
send_qqmail(message)