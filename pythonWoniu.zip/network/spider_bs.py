from bs4 import BeautifulSoup
import requests
resp= requests.get('http://www.zenghuinote.asia/')
#初始化解析器
html = BeautifulSoup(resp.text,'lxml')   #第一个参数要解析的文档，第二个参数解析器的类型
#根据标签层次查找页面元素
# print(html.head.title)   #查找head标记下的title标签的内容
# print(html.head.title.string) #加上.string为获取标签内的文本内容
# print(html.div)   #默认找的是第一个div中包含的所有内容
# print(html.div.div)

#查找页面元素的通用方法：find_all（根据标签，属性，XPATH等进行查找）,select（根据css选择器）
#查找页面所有超链接
# links=html.find_all('a')
# for link in links:
#     try:
#         print(link['href'])
#     except:
#         continue

#查找页面的图片
# images=html.find_all('img')
# for image in images:
#     try:
#         print(image['src'])
#     except:
#         continue

#根据id属性查找
#find_all()找所有，find()只找一个
# keyword= html.find(id='keyword')
# print(keyword)
# print(keyword['type'])


# 根据class属性查找
#查找class属性为title的
# titles=html.find_all(class_='title')  #因为class是python的关键字所以为了区分后面加一个_
# for title in titles:
#     print(title.string)
#     print(title.parent)   #.parent可以找上一层的标签


#根据xpath的风格进行查找
# titles=html.find_all('div',{'class':'title'})  #div标签中包含class属性为title的
# for title in titles:
#     print(title)

#css选择器
# # div标签中包含class属性为title的
# titles=html.select('div.title')
# for title in titles:
#     print(title)

#根据id查找
#查找id为keyword的
# keyword=html.select('#keyword')
# print(keyword[0]['placeholder'])

#根据层次查找
lis=html.select('ul li')
print(lis)