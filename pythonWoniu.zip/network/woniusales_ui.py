# from selenium import webdriver
#
# driver=webdriver.Chrome()
# driver.get('http://192.168.131.207:8080/woniusales/')
#
#
# #
# # driver.close()
#
# #name,id等属性需要根据实际更改
# import uiautomation as auto
# desktop = auto.GetRootControl()
#
# # 通过窗口标题获取特定窗口
# window = desktop.WindowControl(searchDepth=1, Name='记事本')
#
# # 获取窗口中的编辑控件
# edit = window.EditControl()
# edit.SendKeys('这是一段测试文本')
# button = window.ButtonControl(Name='保存')
# button.Click()
# # calc.ButtonControl(AutomationiI='num1Button').click()
