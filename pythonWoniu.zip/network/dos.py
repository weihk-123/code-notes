import os,time
from collections import Counter

#采集数据
#采集CPU的一分钟内的平均负载
def get_cpu_load():
    uptime = os.popen('uptime').read()
    uptime = uptime.replace(": ",",")
    cpu_load = float(uptime.split(",")[-3])

    #使用centos命令来对字符串操作
    #cpu_load = os.popen("uptime | awk -F ': ' '{print $2}' | awk -F ',' '{print $1}'").read()
    #cpu_load = float(cpu_load)
    return cpu_load
#采集连接数量
def get_conn_count():
    netstat = os.popen('netstat -ant | wc -l').read()
    return int(netstat)

#采集队列长度
def get_queue_size():
    sslnt = os.popen("ss -lnt | grep :80").read()
    recvq = int(sslnt.split()[1])
    sendq = int(sslnt.split()[2])
    return recvq,sendq

#采集连接数量最多的ip地址
def get_most_ip():
    netstat = os.popen('netstat -ant | grep :80').read()
    line_list = netstat.split('\n')
    ip_list = []
    for line in line_list:
        try:
            temp_list = line.split()
            ip = temp_list[4].split(':')[0]
            ip_list.append(ip)
        except:
            pass
    dict = Counter(ip_list)
    most_ip = dict.most_common(1)
    return most_ip[0][0]

#调用防火墙封锁攻击源ip
def firewall_ip(ip):
    result = os.popen(f"firewall-cmd --add-rich-rule='rule family=ipv4 port port=80 protocol=tcp source address={ip} drop'").read()
    if 'success' in result:
        print(f'已成功将可以攻击源{ip}进行封锁，流量将不再进入')
    else:
        print(f"对可疑攻击源{ip}封锁失败，请人工处理")

if __name__ == '__main__':
    while True:
        cpu = get_cpu_load()
        conn = get_conn_count()
        recvq,sendq = get_queue_size()
        most_ip = get_most_ip()
        print(f"CPU_Load:{get_cpu_load()}, TCP Conn: {get_conn_count()}, TCP Queue:{get_queue_size()}")
        if cpu > 5 or (conn > 500 and recvq > sendq -10):
            print(f'当前系统TCP连接负载过重，CPU使用率过高，存在DOS攻击的可能,可疑的ip地址为:{most_ip}')
            firewall_ip(most_ip)
        time.sleep(5)
            
    
