#用python伪造发送飞秋信息
import socket,time
for i in range(1000):
    s=socket.socket(type=socket.SOCK_DGRAM)
    s.connect(('192.1.100.3',2425))

    packtId= str(time.time())
    name="dalhvkda"
    host="DESKTOP-VRLVORO"
    command=str(0x00000020)
    content="This is the message from Python"
    message="1.0"+packtId+":"+name+":"+host+":"+command+":"+content
    s.send(message.encode())