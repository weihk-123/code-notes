import smtplib,time
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

#定义发件人收件人以及qq第三方登录的密码
sender='971209914@qq.com'
receiver='3198242592@qq.com'
password='cwhvjgqqbxbabgad'
#构建邮件的主体对象
msg=MIMEMultipart()
msg['Subject']='Python测试邮件'    #指定标题
msg['From']=sender             #发件人
msg['To']=receiver             #收件人


body='''
<div style='font-size: 30px;color: red;'>邮件正文</div>
'''
#设置邮件的主体
content = MIMEText(body,'html','utf-8')
msg.attach(content)

#建立与邮件服务器的连接并发送邮件
# try:
server=smtplib.SMTP()
server.connect('smtp.qq.com',587)
server.login(user=sender,password='caonima.')
server.sendmail(sender,receiver,str(msg))
server.quit()
# except:
#     print('发送失败')
