def string_to_unicode_escape(text):
    """
    将字符串中的每个字符转换为HTML Unicode实体
    """
    return ''.join(f"&#x{ord(char):X};" for char in text)
print(string_to_unicode_escape("javascript:alert(8)"))